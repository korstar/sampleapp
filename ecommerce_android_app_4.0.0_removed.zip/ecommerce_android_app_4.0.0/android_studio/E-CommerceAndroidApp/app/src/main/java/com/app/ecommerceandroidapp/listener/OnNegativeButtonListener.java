package com.app.ecommerceandroidapp.listener;

public interface OnNegativeButtonListener {

    void onNegative();

}