package com.app.ecommerceandroidapp.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;

import com.app.ecommerceandroidapp.BuildConfig;
import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.utilities.DBHelper;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.snackbar.Snackbar;

public class ActivityProductDetail extends AppCompatActivity {

    long product_id;
    TextView txt_product_name, txt_product_price, txt_product_quantity;
    private String product_name, product_image, category_name, product_status, product_description;
    private double product_price;
    private int product_quantity;
    WebView webView;
    ImageView img_product_image;
    Button btn_cart;
    ImageView cart_badge;
    public static DBHelper dbHelper;
    final Context context = this;
    private AppBarLayout appBarLayout;
    SharedPref sharedPref;
    CoordinatorLayout parent_view;
    TextView toolbar_title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_product_detail);
        Tools.lightNavigation(this);

        dbHelper = new DBHelper(this);
        sharedPref = new SharedPref(this);

        getData();
        initComponent();
        displayData();
        setupToolbar();
    }

    public void setupToolbar() {
        final Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("");
        }
        onToolbarIconClicked();
        toolbar_title.setText(category_name);
    }

    public void getData() {
        Intent intent = getIntent();
        product_id = intent.getLongExtra("product_id", 0);
        product_name = intent.getStringExtra("title");
        product_image = intent.getStringExtra("image");
        product_price = intent.getDoubleExtra("product_price", 0);
        product_description = intent.getStringExtra("product_description");
        product_quantity = intent.getIntExtra("product_quantity", 0);
        product_status = intent.getStringExtra("product_status");
        category_name = intent.getStringExtra("category_name");
    }

    public void initComponent() {
        txt_product_name = findViewById(R.id.product_name);
        img_product_image = findViewById(R.id.product_image);
        txt_product_price = findViewById(R.id.product_price);
        webView = findViewById(R.id.product_description);
        txt_product_quantity = findViewById(R.id.product_quantity);
        btn_cart = findViewById(R.id.btn_add_cart);
        cart_badge = findViewById(R.id.cart_badge);
        parent_view = findViewById(R.id.parent_view);
        toolbar_title = findViewById(R.id.toolbar_title);
    }

    public void displayData() {
        txt_product_name.setText(product_name);

        Glide.with(this)
                .load(Config.ADMIN_PANEL_URL + "/upload/product/" + product_image.replace(" ", "%20"))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.ic_loading)
                .into(img_product_image);

        img_product_image.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), ActivityImageDetail.class);
            intent.putExtra("title", product_name);
            intent.putExtra("image", Config.ADMIN_PANEL_URL + "/upload/product/" + product_image);
            startActivity(intent);
        });

        txt_product_price.setText(Tools.decimalFormatter(product_price) + " " + sharedPref.getCurrencyCode());

        txt_product_quantity.setText(product_quantity + " " + getString(R.string.txt_items));

        if (product_status.equals("1")) {

            refreshCartButton();

            btn_cart.setOnClickListener(v -> {
                if (dbHelper.isDataExist(product_id)) {
                    dbHelper.deleteData(product_id);
                    Snackbar.make(parent_view, getString(R.string.msg_remove_cart), Snackbar.LENGTH_SHORT).show();
                    btn_cart.setText(R.string.btn_add_to_cart);
                    new Handler().postDelayed(() -> {
                        btn_cart.setBackgroundColor(ContextCompat.getColor(this, R.color.color_light_status_bar));
                    }, 100);
                } else {
                    dbHelper.addData(product_id, product_name, 1, product_quantity, (product_price * 1), product_image, String.valueOf(System.currentTimeMillis()));
                    Snackbar.make(parent_view, getString(R.string.msg_add_cart), Snackbar.LENGTH_SHORT).show();
                    btn_cart.setText(R.string.btn_remove_from_cart);
                    new Handler().postDelayed(() -> {
                        btn_cart.setBackgroundColor(ContextCompat.getColor(this, R.color.color_orange));
                    }, 100);
                }
                refreshCartBadge();
            });
        } else {
            btn_cart.setEnabled(false);
            btn_cart.setText(R.string.btn_out_of_stock);
            btn_cart.setBackgroundColor(ContextCompat.getColor(this, R.color.color_sold));
        }

        Tools.showContentDescription(this, webView, product_description);

    }

    private void refreshCartButton() {
        if (dbHelper.isDataExist(product_id)) {
            btn_cart.setText(R.string.btn_remove_from_cart);
            btn_cart.setBackgroundColor(ContextCompat.getColor(this, R.color.color_orange));
        } else {
            btn_cart.setText(R.string.btn_add_to_cart);
            btn_cart.setBackgroundColor(ContextCompat.getColor(this, R.color.color_light_status_bar));
        }
    }

    private void refreshCartBadge() {
        if (dbHelper.getAllData().size() > 0) {
            cart_badge.setVisibility(View.VISIBLE);
        } else {
            cart_badge.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == android.R.id.home) {
            onBackPressed();
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
        return true;
    }

    private void onToolbarIconClicked() {
        findViewById(R.id.btn_share).setOnClickListener(view -> shareProduct());
        findViewById(R.id.btn_cart).setOnClickListener(view -> startActivity(new Intent(getApplicationContext(), ActivityCart.class)));
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshCartButton();
        refreshCartBadge();
    }

    private void shareProduct() {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
        intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_product_section_one) + " " + product_name + " " + getString(R.string.share_product_section_two) + " " + Tools.decimalFormatter(product_price) + " " + sharedPref.getCurrencyCode() + getString(R.string.share_product_section_three) + "\n" + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
        intent.setType("text/plain");
        startActivity(intent);
    }

}
