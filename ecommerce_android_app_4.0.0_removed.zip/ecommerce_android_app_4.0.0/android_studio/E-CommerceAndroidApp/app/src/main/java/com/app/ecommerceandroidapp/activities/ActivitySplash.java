package com.app.ecommerceandroidapp.activities;

import static com.app.ecommerceandroidapp.utilities.Constant.GET_SETTINGS;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;

import org.json.JSONException;

public class ActivitySplash extends AppCompatActivity {

    public static final String TAG = "ActivitySplash";
    private final boolean show = true;
    SplashScreen splashScreen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Config.ENABLE_SPLASH_SCREEN_API) {
            splashScreen = SplashScreen.installSplashScreen(this);
        }
        Tools.getTheme(this);
        setContentView(R.layout.activity_splash);
        Tools.lightNavigation(this);

        if (Config.ENABLE_SPLASH_SCREEN_API) {
            splashScreen.setKeepOnScreenCondition(() -> show);
        }

        requestConfig();
    }

    private void requestConfig() {
        Log.d(TAG, "request config");
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, GET_SETTINGS, null, response -> {
            try {
                SharedPref sharedPref = new SharedPref(ActivitySplash.this);
                sharedPref.setConfig(
                        response.getString("currency_code"),
                        response.getInt("tax"),
                        response.getString("privacy_policy")
                );
                startMainActivity();
                Log.d(TAG, "Success: " + response);
            } catch (JSONException e) {
                e.printStackTrace();
                startMainActivity();
                Log.d(TAG, "Error: " + e.getMessage());
            }
        }, error -> {
            startMainActivity();
            Log.d(TAG, "Error: " + error.getMessage());
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq);
    }

    private void startMainActivity() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }

}