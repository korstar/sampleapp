package com.app.ecommerceandroidapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.models.Product;
import com.app.ecommerceandroidapp.utilities.Constant;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.util.List;

public class AdapterProduct extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    private List<Product> productList;
    SharedPref sharedPref;
    private OnItemClickListener mOnItemClickListener;
    private final int VIEW_ITEM = 0;

    public interface OnItemClickListener {
        void onItemClick(View view, Product product, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        public TextView product_name;
        public TextView product_price;
        public ImageView product_image;
        public LinearLayout lyt_parent;

        public OriginalViewHolder(View view) {
            super(view);
            product_name = view.findViewById(R.id.product_name);
            product_price = view.findViewById(R.id.product_price);
            product_image = view.findViewById(R.id.category_image);
            lyt_parent = view.findViewById(R.id.lyt_parent);
        }
    }

    public AdapterProduct(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
        this.sharedPref = new SharedPref(context);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
            vh = new OriginalViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
            vh = new OriginalViewHolder(v);
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if (holder instanceof OriginalViewHolder) {

            final Product product = productList.get(position);
            OriginalViewHolder vItem = (OriginalViewHolder) holder;

            vItem.product_name.setText(product.product_name);

            vItem.product_price.setText(Tools.decimalFormatter(product.product_price) + " " + sharedPref.getCurrencyCode());

            Glide.with(context)
                    .load(Config.ADMIN_PANEL_URL + "/upload/product/" + product.product_image)
                    .apply(new RequestOptions().override(Constant.IMAGE_THUMBNAIL_WIDTH, Constant.IMAGE_THUMBNAIL_HEIGHT))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.ic_loading)
                    .into(vItem.product_image);

            vItem.lyt_parent.setOnClickListener(v -> {
                if (mOnItemClickListener != null) {
                    mOnItemClickListener.onItemClick(v, product, position);
                }
            });

        }

    }

    @Override
    public int getItemViewType(int position) {
        return VIEW_ITEM;
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public void setListData(List<Product> posts) {
        this.productList = posts;
        notifyDataSetChanged();
    }

    public void resetListData() {
        this.productList.clear();
        notifyDataSetChanged();
    }

}
