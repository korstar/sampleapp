package com.app.ecommerceandroidapp;

public class Config {

    //your admin panel url
    public static final String ADMIN_PANEL_URL = "http://10.0.2.2/ecommerce";

    //onesignal app id for push notification
    public static final String ONESIGNAL_APP_ID = "00000000-0000-0000-0000-000000000000";

    //set false if you want price to be displayed in decimal
    public static final boolean ENABLE_DECIMAL_ROUNDING = true;

    //set true if you want to enable RTL (Right To Left) mode, e.g : Arabic Language
    public static final boolean ENABLE_RTL_MODE = false;

    //Set false if you want to use legacy splash screen with custom image background
    public static final boolean ENABLE_SPLASH_SCREEN_API = true;

    //duration of automatic slider switching in the home menu
    public static final int AUTO_SLIDER_DURATION = 6000;

    //delay swipe down to refresh the page
    public static final int DELAY_REFRESH = 1000;

}