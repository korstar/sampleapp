package com.app.ecommerceandroidapp.listener;

public interface OnCompleteListener {

    void onComplete();

}