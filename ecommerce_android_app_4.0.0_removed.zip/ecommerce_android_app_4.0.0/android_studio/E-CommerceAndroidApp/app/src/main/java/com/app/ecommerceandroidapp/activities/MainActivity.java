package com.app.ecommerceandroidapp.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.database.SQLException;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.fragments.FragmentCategory;
import com.app.ecommerceandroidapp.fragments.FragmentHelp;
import com.app.ecommerceandroidapp.fragments.FragmentHome;
import com.app.ecommerceandroidapp.fragments.FragmentProfile;
import com.app.ecommerceandroidapp.utilities.DBHelper;
import com.app.ecommerceandroidapp.utilities.OneSignalPush;
import com.app.ecommerceandroidapp.utilities.RtlViewPager;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";
    private BottomNavigationView navigation;
    public ViewPager viewPager;
    public RtlViewPager viewPagerRtl;
    Toolbar toolbar;
    TextView toolbar_title;
    MenuItem prevMenuItem;
    int pager_number = 4;
    DBHelper dbhelper;
    View view;
    ImageView cart_badge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_main);
        view = findViewById(android.R.id.content);
        Tools.lightNavigation(this);

        initView();
        initViewPager();
        initDb();
        if (getIntent() != null) {
            notificationOpenHandler(getIntent());
        }
        Tools.postDelayed(() -> {
            new OneSignalPush.Builder(this).requestNotificationPermission();
        }, 500);

    }

    private void initView() {
        toolbar = findViewById(R.id.toolbar);
        toolbar_title = findViewById(R.id.toolbar_title);
        setSupportActionBar(toolbar);
        toolbar_title.setText(getString(R.string.app_name));

        cart_badge = findViewById(R.id.cart_badge);

        navigation = findViewById(R.id.navigation);
        viewPager = findViewById(R.id.viewpager);
        viewPagerRtl = findViewById(R.id.viewpager_rtl);

        navigation.setLabelVisibilityMode(BottomNavigationView.LABEL_VISIBILITY_LABELED);
        navigation.setBackgroundColor(ContextCompat.getColor(this, R.color.color_light_bottom_navigation));

        findViewById(R.id.btn_cart).setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), ActivityCart.class);
            startActivity(intent);
        });

        findViewById(R.id.btn_search).setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), ActivitySearch.class);
            startActivity(intent);
        });
    }

    private void initDb() {
        dbhelper = new DBHelper(this);
        try {
            dbhelper.createDataBase();
        } catch (IOException ioe) {
            throw new Error("Unable to create database");
        }

        try {
            dbhelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }
    }

    private void initViewPager() {
        if (Config.ENABLE_RTL_MODE) {
            viewPagerRtl.setVisibility(View.VISIBLE);
            viewPager.setVisibility(View.GONE);
            viewPagerRtl.setAdapter(new MyAdapter(getSupportFragmentManager()));
            viewPagerRtl.setOffscreenPageLimit(pager_number);
            navigation.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    viewPagerRtl.setCurrentItem(0);
                    return true;
                } else if (itemId == R.id.nav_updates) {
                    viewPagerRtl.setCurrentItem(1);
                    return true;
                } else if (itemId == R.id.nav_info) {
                    viewPagerRtl.setCurrentItem(2);
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    viewPagerRtl.setCurrentItem(3);
                    return true;
                }
                return false;
            });

            viewPagerRtl.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    if (prevMenuItem != null) {
                        prevMenuItem.setChecked(false);
                    } else {
                        navigation.getMenu().getItem(0).setChecked(false);
                    }
                    navigation.getMenu().getItem(position).setChecked(true);
                    prevMenuItem = navigation.getMenu().getItem(position);

                    if (viewPagerRtl.getCurrentItem() == 1) {
                        toolbar_title.setText(getString(R.string.title_nav_post));
                    } else if (viewPagerRtl.getCurrentItem() == 2) {
                        toolbar_title.setText(getString(R.string.title_nav_help));
                    } else if (viewPagerRtl.getCurrentItem() == 3) {
                        toolbar_title.setText(getString(R.string.title_nav_profile));
                    } else {
                        toolbar_title.setText(getString(R.string.app_name));
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
        } else {
            viewPagerRtl.setVisibility(View.GONE);
            viewPager.setVisibility(View.VISIBLE);
            viewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));
            viewPager.setOffscreenPageLimit(pager_number);
            navigation.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    viewPager.setCurrentItem(0);
                    return true;
                } else if (itemId == R.id.nav_updates) {
                    viewPager.setCurrentItem(1);
                    return true;
                } else if (itemId == R.id.nav_info) {
                    viewPager.setCurrentItem(2);
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    viewPager.setCurrentItem(3);
                    return true;
                }
                return false;
            });

            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    if (prevMenuItem != null) {
                        prevMenuItem.setChecked(false);
                    } else {
                        navigation.getMenu().getItem(0).setChecked(false);
                    }
                    navigation.getMenu().getItem(position).setChecked(true);
                    prevMenuItem = navigation.getMenu().getItem(position);

                    if (viewPager.getCurrentItem() == 1) {
                        toolbar_title.setText(getString(R.string.title_nav_post));
                    } else if (viewPager.getCurrentItem() == 2) {
                        toolbar_title.setText(getString(R.string.title_nav_help));
                    } else if (viewPager.getCurrentItem() == 3) {
                        toolbar_title.setText(getString(R.string.title_nav_profile));
                    } else {
                        toolbar_title.setText(getString(R.string.app_name));
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
        }
    }

    public void notificationOpenHandler(Intent getIntent) {

        if (getIntent.hasExtra(OneSignalPush.EXTRA_ID)) {

            String id = getIntent.getStringExtra(OneSignalPush.EXTRA_ID);
            String title = getIntent.getStringExtra(OneSignalPush.EXTRA_TITLE);
            String message = getIntent.getStringExtra(OneSignalPush.EXTRA_MESSAGE);
            String bigImage = getIntent.getStringExtra(OneSignalPush.EXTRA_IMAGE);
            String launchUrl = getIntent.getStringExtra(OneSignalPush.EXTRA_LAUNCH_URL);

            String uniqueId = getIntent.getStringExtra(OneSignalPush.EXTRA_UNIQUE_ID);
            String postId = getIntent.getStringExtra(OneSignalPush.EXTRA_POST_ID);
            String link = getIntent.getStringExtra(OneSignalPush.EXTRA_LINK);

            if (link != null && !link.equals("")) {
                if (!link.equals("0")) {
                    Intent intent = new Intent(getApplicationContext(), ActivityWebView.class);
                    intent.putExtra(OneSignalPush.EXTRA_TITLE, title);
                    intent.putExtra(OneSignalPush.EXTRA_LAUNCH_URL, launchUrl);
                    startActivity(intent);
                }
            }

            if (postId != null && !postId.equals("")) {
                if (!postId.equals("0")) {
                    Intent intent;
                    if (postId.equals("1010101010")) {
                        intent = new Intent(getApplicationContext(), ActivityHistory.class);
                    } else {
                        intent = new Intent(getApplicationContext(), ActivityNotificationDetail.class);
                        intent.putExtra(OneSignalPush.EXTRA_UNIQUE_ID, uniqueId);
                        intent.putExtra(OneSignalPush.EXTRA_POST_ID, postId);
                    }
                    startActivity(intent);
                }
            }

        }

    }

    @SuppressWarnings("deprecation")
    public class MyAdapter extends FragmentPagerAdapter {

        public MyAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {

            switch (position) {
                case 0:
                    return new FragmentHome();
                case 1:
                    return new FragmentCategory();
                case 2:
                    return new FragmentHelp();
                case 3:
                    return new FragmentProfile();
            }
            return null;
        }

        @Override
        public int getCount() {
            return pager_number;
        }

    }

    public void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.confirm);
        builder.setMessage(getString(R.string.db_exist_alert));
        builder.setCancelable(false);
        builder.setPositiveButton(getString(R.string.dialog_option_yes), (dialog, which) -> {
            dbhelper.deleteAllData();
            dbhelper.close();
        });

        builder.setNegativeButton(getString(R.string.dialog_option_no), (dialog, which) -> {
            dbhelper.close();
            dialog.cancel();
        });
        AlertDialog alert = builder.create();
        alert.show();

    }

    private void refreshCartBadge() {
        if (dbhelper.getAllData().size() > 0) {
            cart_badge.setVisibility(View.VISIBLE);
        } else {
            cart_badge.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshCartBadge();
    }

    @Override
    public void onBackPressed() {
        if (Config.ENABLE_RTL_MODE) {
            if (viewPagerRtl.getCurrentItem() != 0) {
                viewPagerRtl.setCurrentItem((0), true);
            } else {
                exitApp();
            }
        } else {
            if (viewPager.getCurrentItem() != 0) {
                viewPager.setCurrentItem((0), true);
            } else {
                exitApp();
            }
        }
    }

    public void exitApp() {
        Tools.showAlertDialogExit(
                this,
                getString(R.string.app_name),
                getString(R.string.msg_exit),
                () -> {
                    finish();
                }
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    public void openFragmentCategory() {
        if (Config.ENABLE_RTL_MODE) {
            viewPagerRtl.setCurrentItem(1);
        } else {
            viewPager.setCurrentItem(1);
        }
    }

}
