package com.app.ecommerceandroidapp.models;

public class Product {

    public long product_id;
    public String product_name;
    public String category_id;
    public String category_name;
    public double product_price;
    public String product_status;
    public String product_image;
    public String product_description;
    public String currency_code;
    public double tax;
    public int product_quantity;

}