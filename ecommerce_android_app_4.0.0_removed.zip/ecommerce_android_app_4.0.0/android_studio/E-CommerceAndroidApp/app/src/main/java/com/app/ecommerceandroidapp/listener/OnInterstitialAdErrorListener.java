package com.app.ecommerceandroidapp.listener;

public interface OnInterstitialAdErrorListener {
    void onInterstitialAdError();
}