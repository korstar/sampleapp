package com.app.ecommerceandroidapp.models;

public class Category {

    private String category_id;
    private String category_name;
    private String category_image;
    private String product_count;

    public String getCategoryId() {
        return category_id;
    }

    public String getCategoryName() {
        return category_name;
    }

    public String getCategoryImage() {
        return category_image;
    }

    public String getProductCount() {
        return product_count;
    }

    public Category(String category_id, String category_name, String category_image, String product_count) {
        this.category_id = category_id;
        this.category_name = category_name;
        this.category_image = category_image;
        this.product_count = product_count;
    }
}
