package com.app.ecommerceandroidapp.adapters;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.models.Slider;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.List;

public class AdapterSlider extends PagerAdapter {

    Context context;
    List<Slider> items;
    private OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(View view, Slider slider);
    }

    public boolean isViewFromObject(@NonNull View view, @NonNull Object obj) {
        return view == obj;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public AdapterSlider(Context context, List<Slider> list) {
        this.context = context;
        this.items = list;
    }

    @NonNull
    public Object instantiateItem(ViewGroup viewGroup, int position) {
        final Slider slider = items.get(position);
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_slider, viewGroup, false);

        ImageView sliderImage = inflate.findViewById(R.id.slider_image);
        Glide.with(context)
                .load(Config.ADMIN_PANEL_URL + "/upload/slider/" + slider.slider_image)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.ic_loading)
                .into(sliderImage);

        ((TextView) inflate.findViewById(R.id.slider_title)).setText(Html.fromHtml(slider.slider_title));

        inflate.findViewById(R.id.lyt_parent).setOnClickListener(view -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(view, slider);
            }
        });

        viewGroup.addView(inflate);
        return inflate;
    }

    public int getCount() {
        return this.items.size();
    }

    public void destroyItem(ViewGroup viewGroup, int i, @NonNull Object obj) {
        viewGroup.removeView((View) obj);
    }

}