package com.app.ecommerceandroidapp.listener;

public interface OnNeutralButtonListener {

    void onNeutral();

}