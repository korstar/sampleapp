package com.app.ecommerceandroidapp.listener;

public interface OnPositiveButtonListener {

    void onPositive();

}