package com.app.ecommerceandroidapp.listener;

public interface OnNotificationClickListener {

    void onComplete();

}