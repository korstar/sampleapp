package com.app.ecommerceandroidapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.models.Product;
import com.app.ecommerceandroidapp.utilities.Constant;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.solodroid.ads.sdk.format.NativeAdViewHolder;

import java.util.List;

public class AdapterProduct extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    private List<Product> productList;
    SharedPref sharedPref;
    private OnItemClickListener mOnItemClickListener;
    private final int VIEW_ITEM = 0;
    private final int VIEW_AD = 1;

    public interface OnItemClickListener {
        void onItemClick(View view, Product product, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        public TextView product_name;
        public TextView product_price;
        public ImageView product_image;
        public LinearLayout lyt_parent;

        public OriginalViewHolder(View view) {
            super(view);
            product_name = view.findViewById(R.id.product_name);
            product_price = view.findViewById(R.id.product_price);
            product_image = view.findViewById(R.id.category_image);
            lyt_parent = view.findViewById(R.id.lyt_parent);
        }
    }

    public AdapterProduct(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
        this.sharedPref = new SharedPref(context);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
            vh = new OriginalViewHolder(v);
        } else if (viewType == VIEW_AD) {
            View v = LayoutInflater.from(parent.getContext()).inflate(com.solodroid.ads.sdk.R.layout.view_native_ad_medium, parent, false);
            vh = new NativeAdViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
            vh = new OriginalViewHolder(v);
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if (holder instanceof OriginalViewHolder) {

            final Product product = productList.get(position);
            OriginalViewHolder vItem = (OriginalViewHolder) holder;

            vItem.product_name.setText(product.product_name);

            vItem.product_price.setText(Tools.decimalFormatter(product.product_price) + " " + sharedPref.getCurrencyCode());

            Glide.with(context)
                    .load(Config.ADMIN_PANEL_URL + "/upload/product/" + product.product_image)
                    .apply(new RequestOptions().override(Constant.IMAGE_THUMBNAIL_WIDTH, Constant.IMAGE_THUMBNAIL_HEIGHT))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.ic_loading)
                    .into(vItem.product_image);

            vItem.lyt_parent.setOnClickListener(v -> {
                if (mOnItemClickListener != null) {
                    mOnItemClickListener.onItemClick(v, product, position);
                }
            });

        } else if (holder instanceof NativeAdViewHolder) {

            final NativeAdViewHolder vItem = (NativeAdViewHolder) holder;

            vItem.loadNativeAd(context,
                    context.getString(R.string.ad_status),
                    1,
                    context.getString(R.string.main_ads),
                    context.getString(R.string.backup_ads),
                    context.getString(R.string.admob_native_unit_id),
                    context.getString(R.string.ad_manager_native_unit_id),
                    context.getString(R.string.fan_native_unit_id),
                    context.getString(R.string.applovin_native_manual_unit_id),
                    context.getString(R.string.applovin_banner_mrec_zone_id),
                    context.getString(R.string.wortise_native_unit_id),
                    false,
                    false,
                    "default",
                    R.color.color_native_background,
                    R.color.color_native_background
            );

            vItem.setNativeAdBackgroundResource(R.drawable.bg_native_ad);

            vItem.setNativeAdMargin(
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_xsmall),
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_xsmall),
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_xsmall),
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_xsmall)
            );

            vItem.setNativeAdPadding(
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_none),
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_small),
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_none),
                    context.getResources().getDimensionPixelOffset(R.dimen.spacing_small)
            );

        }

        StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) holder.itemView.getLayoutParams();
        layoutParams.setFullSpan(getItemViewType(position) == VIEW_AD);

    }

    @Override
    public int getItemViewType(int position) {
        Product product = productList.get(position);
        if (product != null) {
            if (product.product_name == null || product.product_name.isEmpty()) {
                return VIEW_AD;
            } else {
                return VIEW_ITEM;
            }
        } else {
            return VIEW_ITEM;
        }
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public void setListData(List<Product> posts) {
        this.productList = posts;
        notifyDataSetChanged();
    }

    public void resetListData() {
        this.productList.clear();
        notifyDataSetChanged();
    }

}
