package com.app.ecommerceandroidapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.utilities.AdsManager;
import com.app.ecommerceandroidapp.utilities.Constant;
import com.app.ecommerceandroidapp.utilities.Tools;

public class ActivityHelp extends AppCompatActivity {

    String str_title, str_content;
    WebView webView;
    AdsManager adsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_help);
        Tools.lightNavigation(this);

        Intent intent = getIntent();
        str_title = intent.getStringExtra("title");
        str_content = intent.getStringExtra("content");

        final Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("");
        }
        ((TextView) findViewById(R.id.toolbar_title)).setText(str_title);

        findViewById(R.id.btn_share).setVisibility(View.GONE);

        webView = findViewById(R.id.web_view);

        Tools.showContentDescription(this, webView, str_content);

        initAds();

    }

    private void initAds() {
        adsManager = new AdsManager(this);
        adsManager.loadBannerAd(Constant.ENABLE_BANNER_AD);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
