package com.app.ecommerceandroidapp.activities;

import static com.app.ecommerceandroidapp.utilities.Constant.GET_SETTINGS;
import static com.solodroid.ads.sdk.util.Constant.ADMOB;
import static com.solodroid.ads.sdk.util.Constant.APPLOVIN;
import static com.solodroid.ads.sdk.util.Constant.APPLOVIN_MAX;
import static com.solodroid.ads.sdk.util.Constant.GOOGLE_AD_MANAGER;
import static com.solodroid.ads.sdk.util.Constant.WORTISE;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.utilities.Constant;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;

import org.json.JSONException;

public class ActivitySplash extends AppCompatActivity {

    public static final String TAG = "ActivitySplash";
    private final boolean show = true;
    SplashScreen splashScreen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Config.ENABLE_SPLASH_SCREEN_API) {
            splashScreen = SplashScreen.installSplashScreen(this);
        }
        Tools.getTheme(this);
        setContentView(R.layout.activity_splash);
        Tools.lightNavigation(this);

        if (Config.ENABLE_SPLASH_SCREEN_API) {
            splashScreen.setKeepOnScreenCondition(() -> show);
        }

        requestConfig();
    }

    private void requestConfig() {
        Log.d(TAG, "request config");
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, GET_SETTINGS, null, response -> {
            try {
                SharedPref sharedPref = new SharedPref(ActivitySplash.this);
                sharedPref.setConfig(
                        response.getString("currency_code"),
                        response.getInt("tax"),
                        response.getString("privacy_policy")
                );
                showAppOpenAdIfAvailable();
                Log.d(TAG, "Success: " + response);
            } catch (JSONException e) {
                e.printStackTrace();
                showAppOpenAdIfAvailable();
                Log.d(TAG, "Error: " + e.getMessage());
            }
        }, error -> {
            showAppOpenAdIfAvailable();
            Log.d(TAG, "Error: " + error.getMessage());
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq);
    }

    private void showAppOpenAdIfAvailable() {
        if (getString(R.string.ad_status).equals("1") && Constant.ENABLE_APP_OPEN_AD) {
            Log.d(TAG, "app open ad");
            switch (getString(R.string.main_ads)) {
                case ADMOB:
                    if (!getString(R.string.admob_app_open_unit_id).equals("0")) {
                        ((MyApplication) getApplication()).showAdIfAvailable(ActivitySplash.this, this::startMainActivity);
                        Log.d(TAG, "show if available");
                    } else {
                        startMainActivity();
                        Log.d(TAG, "startMainActivity");
                    }
                    break;
                case GOOGLE_AD_MANAGER:
                    if (!getString(R.string.ad_manager_app_open_unit_id).equals("0")) {
                        ((MyApplication) getApplication()).showAdIfAvailable(ActivitySplash.this, this::startMainActivity);
                    } else {
                        startMainActivity();
                    }
                    break;
                case APPLOVIN:
                case APPLOVIN_MAX:
                    if (!getString(R.string.applovin_open_ad_unit_id).equals("0")) {
                        ((MyApplication) getApplication()).showAdIfAvailable(ActivitySplash.this, this::startMainActivity);
                    } else {
                        startMainActivity();
                    }
                    break;
                case WORTISE:
                    if (!getString(R.string.wortise_app_open_unit_id).equals("0")) {
                        ((MyApplication) getApplication()).showAdIfAvailable(ActivitySplash.this, this::startMainActivity);
                    } else {
                        startMainActivity();
                    }
                    break;
                default:
                    startMainActivity();
                    break;
            }
        } else {
            startMainActivity();
        }
    }

    private void startMainActivity() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }

}