package com.app.ecommerceandroidapp.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.adapters.AdapterProduct;
import com.app.ecommerceandroidapp.adapters.AdapterSearch;
import com.app.ecommerceandroidapp.models.Product;
import com.app.ecommerceandroidapp.utilities.AdsManager;
import com.app.ecommerceandroidapp.utilities.Constant;
import com.app.ecommerceandroidapp.utilities.ItemOffsetDecoration;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class ActivitySearch extends AppCompatActivity {

    private EditText edtSearch;
    private ImageButton btnClear;
    private AdapterSearch adapterSearch;
    private LinearLayout lytSuggestion;
    RecyclerView recyclerView;
    RecyclerView recyclerViewSuggestion;
    List<Product> filteredList;
    AdapterProduct adapterProduct;
    SharedPref sharedPref;
    CoordinatorLayout parentView;
    ShimmerFrameLayout lytShimmer;
    AdsManager adsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_search);
        Tools.lightNavigation(this);
        sharedPref = new SharedPref(this);
        initView();
        setupToolbar();
        initAds();
    }

    private void initAds() {
        adsManager = new AdsManager(this);
        adsManager.loadBannerAd(Constant.ENABLE_BANNER_AD);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void initView() {

        parentView = findViewById(R.id.parent_view);
        lytShimmer = findViewById(R.id.shimmer_view_container);

        edtSearch = findViewById(R.id.et_search);
        btnClear = findViewById(R.id.bt_clear);
        btnClear.setVisibility(View.GONE);

        recyclerView = findViewById(R.id.recycler_view);

        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        recyclerView.addItemDecoration(new ItemOffsetDecoration(this, R.dimen.item_offset));
        adapterProduct = new AdapterProduct(this, sharedPref.getProductList());
        adapterProduct.setOnItemClickListener((view, product, position) -> Tools.onProductListClicked(this, product));

        edtSearch.addTextChangedListener(textWatcher);

        lytSuggestion = findViewById(R.id.lyt_suggestion);
        recyclerViewSuggestion = findViewById(R.id.recycler_view_suggestion);
        recyclerViewSuggestion.setLayoutManager(new LinearLayoutManager(this));

        adapterSearch = new AdapterSearch(this);
        recyclerViewSuggestion.setAdapter(adapterSearch);
        showSuggestionSearch();

        adapterSearch.setOnItemClickListener((view, viewModel, pos) -> {
            edtSearch.setText(viewModel);
            edtSearch.setSelection(viewModel.length());
            lytSuggestion.setVisibility(View.GONE);
            adapterProduct.resetListData();
            hideKeyboard();
            searchAction();
        });

        adapterSearch.setOnItemActionClickListener((view, viewModel, pos) -> {
            edtSearch.setText(viewModel);
            edtSearch.setSelection(viewModel.length());
        });

        btnClear.setOnClickListener(v -> {
            edtSearch.setText("");
        });

        edtSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideKeyboard();
                searchAction();
                return true;
            }
            return false;
        });

        edtSearch.setOnTouchListener((view, motionEvent) -> {
            if (adapterSearch.getItemCount() > 0) {
                showSuggestionSearch();
            } else {
                lytSuggestion.setVisibility(View.GONE);
                showEmptySearch();
            }
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            return false;
        });

        swipeProgress(false);

        if (adapterSearch.getItemCount() <= 0) {
            lytSuggestion.setVisibility(View.GONE);
            showEmptySearch();
        }

    }

    private void setupToolbar() {
        final Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        btnClear.setColorFilter(ContextCompat.getColor(this, R.color.color_white), PorterDuff.Mode.SRC_IN);
        lytSuggestion.setBackgroundColor(ContextCompat.getColor(this, R.color.color_light_background));
    }

    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence c, int i, int i1, int i2) {
            if (c.toString().trim().length() == 0) {
                btnClear.setVisibility(View.GONE);
            } else {
                btnClear.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void beforeTextChanged(CharSequence c, int i, int i1, int i2) {
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    private void searchAction() {
        showNotFoundView(false);
        lytSuggestion.setVisibility(View.GONE);
        final String query = edtSearch.getText().toString().trim();
        if (!query.equals("")) {
            adapterProduct.resetListData();
            swipeProgress(true);
            Tools.postDelayed(() -> {
                requestSearch(sharedPref.getProductList(), query);
                adapterSearch.addSearchHistory(query);
                recyclerView.setAdapter(adapterProduct);
            }, 1000);
        } else {
            Snackbar.make(parentView, getString(R.string.msg_no_search_input), Snackbar.LENGTH_SHORT).show();
            swipeProgress(false);
        }
    }

    private void requestSearch(List<Product> posts, final String query) {
        filteredList = new ArrayList<>();
        if (posts != null && posts.size() > 0) {
            for (Product post : posts) {
                if (post.product_name.toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(post);
                }
            }
            if (filteredList.size() > 0) {
                adapterProduct.setListData(filteredList);
                Tools.insertNativeAd(filteredList, filteredList.size());
                showNotFoundView(false);
                findViewById(R.id.banner_ad_view).setVisibility(View.VISIBLE);
            } else {
                showNotFoundView(true);
            }
            swipeProgress(false);
        }
    }

    private void showSuggestionSearch() {
        adapterSearch.refreshItems();
        lytSuggestion.setVisibility(View.VISIBLE);
    }

    private void swipeProgress(boolean show) {
        if (show) {
            lytShimmer.setVisibility(View.VISIBLE);
            lytShimmer.startShimmer();
            recyclerView.setVisibility(View.GONE);
        } else {
            lytShimmer.setVisibility(View.GONE);
            lytShimmer.stopShimmer();
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void showNotFoundView(boolean show) {
        View lytNotFound = findViewById(R.id.lyt_no_item);
        if (show) {
            recyclerView.setVisibility(View.GONE);
            lytNotFound.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            lytNotFound.setVisibility(View.GONE);
        }
    }

    private void showEmptySearch() {
        View lytNotFound = findViewById(R.id.lyt_no_item);
        ((TextView) findViewById(R.id.no_item_title)).setText(getString(R.string.title_menu_search));
        ((TextView) findViewById(R.id.no_item_message)).setText(getString(R.string.msg_no_search_input));
        lytNotFound.setVisibility(View.VISIBLE);
    }

    public void hideKeyboard() {
        try {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            if (getCurrentFocus() != null && getCurrentFocus().getWindowToken() != null) {
                ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (edtSearch.length() > 0) {
            edtSearch.setText("");
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}
