package com.app.ecommerceandroidapp.utilities;

import static com.solodroid.ads.sdk.util.Constant.AD_STATUS_ON;
import static com.solodroid.ads.sdk.util.Constant.IRONSOURCE;

import android.app.Activity;

import com.app.ecommerceandroidapp.BuildConfig;
import com.app.ecommerceandroidapp.R;
import com.solodroid.ads.sdk.format.AdNetwork;
import com.solodroid.ads.sdk.format.AppOpenAd;
import com.solodroid.ads.sdk.format.BannerAd;
import com.solodroid.ads.sdk.format.InterstitialAd;
import com.solodroid.ads.sdk.format.NativeAd;
import com.solodroid.ads.sdk.gdpr.GDPR;

public class AdsManager {

    Activity activity;
    AdNetwork.Initialize adNetwork;
    AppOpenAd.Builder appOpenAd;
    BannerAd.Builder bannerAd;
    InterstitialAd.Builder interstitialAd;
    NativeAd.Builder nativeAd;
    SharedPref sharedPref;
    GDPR gdpr;

    public AdsManager(Activity activity) {
        this.activity = activity;
        this.sharedPref = new SharedPref(activity);
        this.gdpr = new GDPR(activity);
        adNetwork = new AdNetwork.Initialize(activity);
        appOpenAd = new AppOpenAd.Builder(activity);
        bannerAd = new BannerAd.Builder(activity);
        interstitialAd = new InterstitialAd.Builder(activity);
        nativeAd = new NativeAd.Builder(activity);
    }

    public void initializeAd() {
        adNetwork.setAdStatus(activity.getString(R.string.ad_status))
                .setAdNetwork(activity.getString(R.string.main_ads))
                .setBackupAdNetwork(activity.getString(R.string.backup_ads))
                .setStartappAppId(activity.getString(R.string.startapp_app_id))
                .setUnityGameId(activity.getString(R.string.unity_game_id))
                .setIronSourceAppKey(activity.getString(R.string.ironsource_app_key))
                .setWortiseAppId(activity.getString(R.string.wortise_app_id))
                .setDebug(BuildConfig.DEBUG)
                .build();
    }

    public void showAppOpenAd(boolean placement) {
        if (placement) {
            if (activity.getString(R.string.ad_status).equals(AD_STATUS_ON)) {
                appOpenAd.show();
            }
        }
    }

    public void destroyAppOpenAd(boolean placement) {
        if (placement) {
            if (activity.getString(R.string.ad_status).equals(AD_STATUS_ON)) {
                appOpenAd.destroyOpenAd();
            }
        }
    }

    public void loadBannerAd(boolean placement) {
        if (placement) {
            bannerAd.setAdStatus(activity.getString(R.string.ad_status))
                    .setAdNetwork(activity.getString(R.string.main_ads))
                    .setBackupAdNetwork(activity.getString(R.string.backup_ads))
                    .setAdMobBannerId(activity.getString(R.string.admob_banner_unit_id))
                    .setGoogleAdManagerBannerId(activity.getString(R.string.ad_manager_banner_unit_id))
                    .setFanBannerId(activity.getString(R.string.fan_banner_unit_id))
                    .setUnityBannerId(activity.getString(R.string.unity_banner_placement_id))
                    .setAppLovinBannerId(activity.getString(R.string.applovin_banner_unit_id))
                    .setAppLovinBannerZoneId(activity.getString(R.string.applovin_banner_zone_id))
                    .setIronSourceBannerId(activity.getString(R.string.ironsource_banner_placement_name))
                    .setWortiseBannerId(activity.getString(R.string.wortise_banner_unit_id))
                    .setPlacementStatus(1)
                    .build();
        }
    }

    public void loadInterstitialAd(boolean placement, int interval) {
        if (placement) {
            interstitialAd.setAdStatus(activity.getString(R.string.ad_status))
                    .setAdNetwork(activity.getString(R.string.main_ads))
                    .setBackupAdNetwork(activity.getString(R.string.backup_ads))
                    .setAdMobInterstitialId(activity.getString(R.string.admob_interstitial_unit_id))
                    .setGoogleAdManagerInterstitialId(activity.getString(R.string.ad_manager_interstitial_unit_id))
                    .setFanInterstitialId(activity.getString(R.string.fan_interstitial_unit_id))
                    .setUnityInterstitialId(activity.getString(R.string.unity_interstitial_placement_id))
                    .setAppLovinInterstitialId(activity.getString(R.string.applovin_interstitial_unit_id))
                    .setAppLovinInterstitialZoneId(activity.getString(R.string.applovin_interstitial_zone_id))
                    .setIronSourceInterstitialId(activity.getString(R.string.ironsource_interstitial_placement_name))
                    .setWortiseInterstitialId(activity.getString(R.string.wortise_interstitial_unit_id))
                    .setInterval(interval)
                    .setPlacementStatus(1)
                    .build();
        }
    }

    public void loadNativeAd(boolean placement) {
        if (placement) {
            nativeAd.setAdStatus(activity.getString(R.string.ad_status))
                    .setAdNetwork(activity.getString(R.string.main_ads))
                    .setBackupAdNetwork(activity.getString(R.string.backup_ads))
                    .setAdMobNativeId(activity.getString(R.string.admob_native_unit_id))
                    .setAdManagerNativeId(activity.getString(R.string.ad_manager_native_unit_id))
                    .setFanNativeId(activity.getString(R.string.fan_native_unit_id))
                    .setAppLovinNativeId(activity.getString(R.string.applovin_native_manual_unit_id))
                    .setAppLovinDiscoveryMrecZoneId(activity.getString(R.string.applovin_banner_mrec_zone_id))
                    .setWortiseNativeId(activity.getString(R.string.wortise_native_unit_id))
                    .setNativeAdBackgroundColor(R.color.color_native_background, R.color.color_native_background)
                    .setNativeAdStyle("default")
                    .setPlacementStatus(1)
                    .build();
        }
    }

    public void showInterstitialAd() {
        if (activity.getString(R.string.ad_status).equals(AD_STATUS_ON)) {
            interstitialAd.show();
        }
    }

    public void destroyBannerAd() {
        if (activity.getString(R.string.ad_status).equals(AD_STATUS_ON)) {
            bannerAd.destroyAndDetachBanner();
        }
    }

    public void resumeBannerAd(boolean placement) {
        if (activity.getString(R.string.ad_status).equals(AD_STATUS_ON) && !activity.getString(R.string.ironsource_banner_placement_name).equals("0")) {
            if (activity.getString(R.string.main_ads).equals(IRONSOURCE) || activity.getString(R.string.backup_ads).equals(IRONSOURCE)) {
                loadBannerAd(placement);
            }
        }
    }

    public void updateConsentStatus() {
        gdpr.updateGDPRConsentStatus(activity.getString(R.string.main_ads), false, false);
    }

}
