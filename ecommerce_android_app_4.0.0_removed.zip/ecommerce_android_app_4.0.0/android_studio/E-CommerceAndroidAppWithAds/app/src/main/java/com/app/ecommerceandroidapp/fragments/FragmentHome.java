package com.app.ecommerceandroidapp.fragments;

import static com.app.ecommerceandroidapp.utilities.Constant.GET_HOME;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.toolbox.StringRequest;
import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.activities.ActivityCheckout;
import com.app.ecommerceandroidapp.activities.ActivityPostDetail;
import com.app.ecommerceandroidapp.activities.ActivityProduct;
import com.app.ecommerceandroidapp.activities.MainActivity;
import com.app.ecommerceandroidapp.activities.MyApplication;
import com.app.ecommerceandroidapp.adapters.AdapterCategory;
import com.app.ecommerceandroidapp.adapters.AdapterProduct;
import com.app.ecommerceandroidapp.adapters.AdapterSlider;
import com.app.ecommerceandroidapp.models.Category;
import com.app.ecommerceandroidapp.models.Product;
import com.app.ecommerceandroidapp.models.Slider;
import com.app.ecommerceandroidapp.utilities.ItemOffsetDecoration;
import com.app.ecommerceandroidapp.utilities.RtlViewPager;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FragmentHome extends Fragment {

    List<Product> productList;
    List<Category> categoryList;
    List<Slider> sliderList;
    private RecyclerView recyclerViewCategory;
    private RecyclerView recyclerViewProduct;
    AdapterCategory adapterCategory;
    AdapterProduct adapterProduct;
    AdapterSlider adapterSlider;
    SwipeRefreshLayout swipeRefreshLayout = null;
    private Runnable runnableCode = null;
    Handler handler = new Handler();
    private ViewPager viewPagerSlider;
    private RtlViewPager viewPagerSliderRtl;
    TabLayout tabLayout;
    View rootView;
    LinearLayout lytContent;
    ShimmerFrameLayout lytShimmer;
    Activity activity;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (Activity) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_home, container, false);
        swipeRefreshLayout = rootView.findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setRefreshing(true);

        lytShimmer = rootView.findViewById(R.id.shimmer_view_container);
        lytContent = rootView.findViewById(R.id.lyt_content);
        recyclerViewCategory = rootView.findViewById(R.id.recycler_view_category);
        recyclerViewProduct = rootView.findViewById(R.id.recycler_view_product);
        viewPagerSlider = rootView.findViewById(R.id.view_pager_slider);
        viewPagerSliderRtl = rootView.findViewById(R.id.view_pager_slider_rtl);
        tabLayout = rootView.findViewById(R.id.tab_layout);

        //recyclerViewProduct.setLayoutManager(new GridLayoutManager(activity, 2));
        recyclerViewProduct.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        recyclerViewProduct.addItemDecoration(new ItemOffsetDecoration(activity, R.dimen.item_offset));

        recyclerViewCategory.setLayoutManager(new GridLayoutManager(activity, 1, GridLayoutManager.HORIZONTAL, false));
        recyclerViewCategory.addItemDecoration(new ItemOffsetDecoration(activity, R.dimen.item_offset));

        sliderList = new ArrayList<>();
        categoryList = new ArrayList<>();
        productList = new ArrayList<>();

        fetchData();
        onRefresh();

        return rootView;
    }

    private void onRefresh() {
        swipeRefreshLayout.setOnRefreshListener(() -> {
            swipeProgress(true);
            sliderList.clear();
            categoryList.clear();
            productList.clear();
            Tools.postDelayed(this::fetchData, Config.DELAY_REFRESH);
        });
    }

    private void fetchData() {
        StringRequest request = new StringRequest(GET_HOME, response -> {
            if (response == null) {
                showFailedView(true);
                swipeProgress(false);
                return;
            }
            try {
                JSONObject json = new JSONObject(response);
                JSONArray sliderResponse = json.getJSONArray("sliders");
                JSONArray categoryResponse = json.getJSONArray("categories");
                JSONArray productResponse = json.getJSONArray("products");
                JSONArray shippingResponse = json.getJSONArray("shippings");

                ActivityCheckout.arrayList.clear();
                setShipping(shippingResponse);

                List<Category> categories = new Gson().fromJson(categoryResponse.toString(), new TypeToken<List<Category>>() {
                }.getType());
                categoryList.clear();
                categoryList.addAll(categories);
                categoryList.add(new Category("", "", "", ""));

                List<Product> products = new Gson().fromJson(productResponse.toString(), new TypeToken<List<Product>>() {
                }.getType());
                productList.clear();
                productList.addAll(products);
                Tools.insertNativeAd(productList, productList.size());

                List<Slider> sliders = new Gson().fromJson(sliderResponse.toString(), new TypeToken<List<Slider>>() {
                }.getType());
                sliderList.clear();
                sliderList.addAll(sliders);

                displaySliders(sliderList);
                displayCategories(categoryList);
                displayProducts(productList);

                ((TextView) rootView.findViewById(R.id.txt_home_category)).setText(getString(R.string.txt_home_category));
                ((TextView) rootView.findViewById(R.id.txt_home_product)).setText(getString(R.string.txt_home_menu));

                SharedPref sharedPref = new SharedPref(activity);
                sharedPref.saveProductList(products);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            swipeProgress(false);
            showFailedView(false);
        }, error -> {
            showFailedView(true);
            swipeProgress(false);
        });

        MyApplication.getInstance().addToRequestQueue(request);
    }



    private void displayCategories(List<Category> categories) {
        adapterCategory = new AdapterCategory(activity, categories, category -> {
            if (category.getCategoryId().isEmpty()) {
                new Handler(Looper.getMainLooper()).postDelayed(() -> ((MainActivity) activity).openFragmentCategory(), 250);
            } else {
                Intent intent = new Intent(activity, ActivityProduct.class);
                intent.putExtra("category_id", category.getCategoryId());
                intent.putExtra("category_name", category.getCategoryName());
                startActivity(intent);
                ((MainActivity) activity).showInterstitialAd();
            }
        }, true);
        recyclerViewCategory.setAdapter(adapterCategory);
    }

    private void displayProducts(List<Product> products) {
        adapterProduct = new AdapterProduct(activity, products);
        adapterProduct.setOnItemClickListener((view, product, position) -> {
            Tools.onProductListClicked(activity, product);
            ((MainActivity) activity).showInterstitialAd();
        });
        recyclerViewProduct.setAdapter(adapterProduct);
    }

    private void displaySliders(List<Slider> sliders) {
        adapterSlider = new AdapterSlider(activity, sliders);
        if (Config.ENABLE_RTL_MODE) {
            viewPagerSliderRtl.setVisibility(View.VISIBLE);
            viewPagerSlider.setVisibility(View.GONE);
            viewPagerSliderRtl.setAdapter(adapterSlider);
            viewPagerSliderRtl.setOffscreenPageLimit(4);
            tabLayout.setupWithViewPager(viewPagerSliderRtl, true);
        } else {
            viewPagerSliderRtl.setVisibility(View.GONE);
            viewPagerSlider.setVisibility(View.VISIBLE);
            viewPagerSlider.setAdapter(adapterSlider);
            viewPagerSlider.setOffscreenPageLimit(4);
            tabLayout.setupWithViewPager(viewPagerSlider, true);
        }

        startAutoSlider(sliders.size(), viewPagerSlider, viewPagerSliderRtl);
        adapterSlider.setOnItemClickListener((view, slider) -> {
            Intent intent = new Intent(activity, ActivityPostDetail.class);
            intent.putExtra("title", slider.slider_title);
            intent.putExtra("image", Config.ADMIN_PANEL_URL + "/upload/slider/" + slider.slider_image);
            intent.putExtra("description", slider.slider_description);
            startActivity(intent);
            ((MainActivity) activity).showInterstitialAd();
        });

        if (sliders.isEmpty()) {
            rootView.findViewById(R.id.lyt_slider).setVisibility(View.GONE);
        }
    }

    private void startAutoSlider(final int position, ViewPager viewPager, RtlViewPager viewPagerRtl) {
        if (runnableCode != null) {
            handler.removeCallbacks(runnableCode);
        }
        if (Config.ENABLE_RTL_MODE) {
            runnableCode = () -> {
                int currentItem = viewPagerSliderRtl.getCurrentItem() + 1;
                if (currentItem >= position) {
                    currentItem = 0;
                }
                viewPagerSliderRtl.setCurrentItem(currentItem);
                handler.postDelayed(runnableCode, Config.AUTO_SLIDER_DURATION);
            };
        } else {
            runnableCode = () -> {
                int currentItem = viewPagerSlider.getCurrentItem() + 1;
                if (currentItem >= position) {
                    currentItem = 0;
                }
                viewPagerSlider.setCurrentItem(currentItem);
                handler.postDelayed(runnableCode, Config.AUTO_SLIDER_DURATION);
            };
        }
        handler.postDelayed(runnableCode, Config.AUTO_SLIDER_DURATION);
    }

    private void setShipping(JSONArray jsonArray) {
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject json = jsonArray.getJSONObject(i);
                ActivityCheckout.arrayList.add(json.getString("shipping_name"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void swipeProgress(boolean show) {
        if (show) {
            swipeRefreshLayout.setRefreshing(true);
            lytShimmer.setVisibility(View.VISIBLE);
            lytShimmer.startShimmer();
            lytContent.setVisibility(View.GONE);
        } else {
            swipeRefreshLayout.setRefreshing(false);
            lytShimmer.setVisibility(View.GONE);
            lytShimmer.stopShimmer();
            lytContent.setVisibility(View.VISIBLE);
        }
    }

    private void showFailedView(boolean show) {
        View lytFailed = rootView.findViewById(R.id.lyt_failed);
        if (show) {
            lytFailed.setVisibility(View.VISIBLE);
        } else {
            lytFailed.setVisibility(View.GONE);
        }
    }

}