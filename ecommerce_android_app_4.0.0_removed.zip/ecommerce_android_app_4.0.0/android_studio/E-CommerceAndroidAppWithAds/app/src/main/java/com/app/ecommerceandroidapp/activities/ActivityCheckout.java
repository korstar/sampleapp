package com.app.ecommerceandroidapp.activities;

import static com.app.ecommerceandroidapp.utilities.Constant.POST_ORDER;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.utilities.AdsManager;
import com.app.ecommerceandroidapp.utilities.Constant;
import com.app.ecommerceandroidapp.utilities.DBHelper;
import com.app.ecommerceandroidapp.utilities.MaterialProgressDialog;
import com.app.ecommerceandroidapp.utilities.SharedPref;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.google.android.material.snackbar.Snackbar;
import com.onesignal.OneSignal;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

@SuppressWarnings("deprecation")
public class ActivityCheckout extends AppCompatActivity {

    public static final String TAG = "ActivityCheckout";
    RequestQueue requestQueue;
    Button btn_submit_order;
    EditText edt_name, edt_email, edt_phone, edt_address, edt_shipping, edt_order_list, edt_order_total, edt_comment;
    String str_name, str_email, str_phone, str_address, str_shipping, str_order_list, str_order_total, str_comment;
    String data_order_list = "";
    MaterialProgressDialog.Builder progressDialog;
    DBHelper dbhelper;
    ArrayList<ArrayList<Object>> data;
    private static final String ALLOWED_CHARACTERS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    View view;
    private String rand = getRandomString(9);
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String date = dateFormat.format(Calendar.getInstance().getTime());
    SharedPref sharedPref;
    private Spinner spinner;
    public static ArrayList<String> arrayList = new ArrayList<>();
    String playerId = "";
    AdsManager adsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_checkout);
        Tools.lightNavigation(this);
        view = findViewById(android.R.id.content);

        sharedPref = new SharedPref(this);

        setupToolbar();
        getSpinnerData();

        dbhelper = new DBHelper(this);
        try {
            dbhelper.openDataBase();
        } catch (SQLException sqle) {
            throw sqle;
        }

        requestQueue = Volley.newRequestQueue(this);
        progressDialog = new MaterialProgressDialog.Builder(this);
        progressDialog.build();

        btn_submit_order = findViewById(R.id.btn_submit_order);

        edt_name = findViewById(R.id.edt_name);
        edt_email = findViewById(R.id.edt_email);
        edt_phone = findViewById(R.id.edt_phone);
        edt_address = findViewById(R.id.edt_address);
        edt_shipping = findViewById(R.id.edt_shipping);
        edt_order_list = findViewById(R.id.edt_order_list);
        edt_order_total = findViewById(R.id.edt_order_total);
        edt_comment = findViewById(R.id.edt_comment);

        edt_order_list.setEnabled(false);

        getDataFromDatabase();
        submitOrder();

        edt_name.setText(sharedPref.getName());
        edt_email.setText(sharedPref.getEmail());
        edt_phone.setText(sharedPref.getPhone());
        edt_address.setText(sharedPref.getAddress());

        loadAds();

    }

    private void loadAds() {
        adsManager = new AdsManager(this);
        adsManager.loadBannerAd(Constant.ENABLE_BANNER_AD);
    }

    private static String pad(int c) {
        if (c >= 10) {
            return String.valueOf(c);
        } else {
            return "0" + c;
        }
    }

    public void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.title_checkout);
        }
    }

    private void getSpinnerData() {

        spinner = findViewById(R.id.spinner);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<>(ActivityCheckout.this, R.layout.spinner_item, arrayList);
        myAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinner.setAdapter(myAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                edt_shipping.setText(arrayList.get(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    public void submitOrder() {
        btn_submit_order.setOnClickListener(v -> getValueFromEditText());
    }

    public void getValueFromEditText() {

        str_name = edt_name.getText().toString();
        str_email = edt_email.getText().toString();
        str_phone = edt_phone.getText().toString();
        str_address = edt_address.getText().toString();
        str_shipping = edt_shipping.getText().toString();
        str_order_list = edt_order_list.getText().toString();
        str_order_total = edt_order_total.getText().toString();
        str_comment = edt_comment.getText().toString();

        if (str_name.equalsIgnoreCase("") ||
                str_email.equalsIgnoreCase("") ||
                str_phone.equalsIgnoreCase("") ||
                str_address.equalsIgnoreCase("") ||
                str_shipping.equalsIgnoreCase("") ||
                str_order_list.equalsIgnoreCase("")) {
            Snackbar.make(view, R.string.checkout_fill_form, Snackbar.LENGTH_SHORT).show();
        } else {
            Tools.showAlertDialog(
                    this,
                    getString(R.string.checkout_dialog_title),
                    getString(R.string.checkout_dialog_msg),
                    this::requestAction
            );
        }
    }

    public void requestAction() {

        progressDialog.setMessage(getString(R.string.checkout_submit_msg));
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, POST_ORDER, ServerResponse -> {
            Tools.postDelayed(() -> {
                progressDialog.dismiss();
                dialogSuccessOrder();
                sharedPref.saveProfile(str_name, str_email, str_phone, str_address);
            }, 2000);

        }, volleyError -> {
            progressDialog.dismiss();
            Toast.makeText(getApplicationContext(), getString(R.string.checkout_error), Toast.LENGTH_LONG).show();
        }) {
            @Override
            protected Map<String, String> getParams() {

                playerId = OneSignal.getUser().getPushSubscription().getId();

                @SuppressLint("SimpleDateFormat") String str_date = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
                @SuppressLint("SimpleDateFormat") String str_time = new SimpleDateFormat("HH:mm:00").format(Calendar.getInstance().getTime());

                Map<String, String> params = new HashMap<>();
                params.put("code", rand);
                params.put("name", str_name);
                params.put("email", str_email);
                params.put("phone", str_phone);
                params.put("address", str_address);
                params.put("date_time", str_date + " " + str_time);
                params.put("shipping", str_shipping);
                params.put("order_list", str_order_list);
                params.put("order_total", str_order_total);
                params.put("comment", str_comment);
                if (!playerId.isEmpty()) {
                    params.put("player_id", playerId);
                } else {
                    params.put("player_id", "0");
                }
                params.put("date", date);
                params.put("server_url", Config.ADMIN_PANEL_URL);

                return params;
            }

        };

        DefaultRetryPolicy retryPolicy = new DefaultRetryPolicy(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);
        RequestQueue requestQueue = Volley.newRequestQueue(ActivityCheckout.this);
        requestQueue.add(stringRequest);
    }

    public void getDataFromDatabase() {

        data = dbhelper.getAllData();

        double Order_price = 0;
        double Total_price = 0;
        double tax = 0;

        for (int i = 0; i < data.size(); i++) {
            ArrayList<Object> row = data.get(i);

            String Menu_name = row.get(1).toString();
            String Quantity = row.get(2).toString();

            double Sub_total_price = Double.parseDouble(row.get(4).toString());

            String _Sub_total_price = String.format(Locale.GERMAN, "%1$,.0f", Sub_total_price);

            Order_price += Sub_total_price;

            data_order_list += (Quantity + " " + Menu_name + " " + Tools.decimalFormatter(Sub_total_price) + " " + sharedPref.getCurrencyCode() + ",\n");
        }

        if (data_order_list.equalsIgnoreCase("")) {
            data_order_list += getString(R.string.no_order_menu);
        }

        tax = Order_price * ((double) sharedPref.getTax() / 100);
        Total_price = Order_price + tax;

        String price_tax = String.format(Locale.GERMAN, "%1$,.0f", (double) sharedPref.getTax());
        String _Order_price = String.format(Locale.GERMAN, "%1$,.0f", Order_price);
        String _tax = String.format(Locale.GERMAN, "%1$,.0f", tax);
        String _Total_price = String.format(Locale.GERMAN, "%1$,.0f", Total_price);

        data_order_list += "\n" + getResources().getString(R.string.txt_order) + " " + Tools.decimalFormatter(Order_price) + " " + sharedPref.getCurrencyCode() +
                "\n" + getResources().getString(R.string.txt_tax) + " " + Tools.decimalFormatter(sharedPref.getTax()) + "%: " + Tools.decimalFormatter(tax) + " " + sharedPref.getCurrencyCode() +
                "\n" + getResources().getString(R.string.txt_total) + " " + Tools.decimalFormatter(Total_price) + " " + sharedPref.getCurrencyCode();

        edt_order_total.setText(Tools.decimalFormatter(Total_price) + " " + sharedPref.getCurrencyCode());

        edt_order_list.setText(data_order_list);

    }

    public void dialogSuccessOrder() {
        Tools.showAlertDialogSuccess(
                this,
                getString(R.string.checkout_success_title),
                getString(R.string.checkout_success_msg),
                () -> {
                    dbhelper.addDataHistory(rand, str_order_list, str_order_total, date);
                    dbhelper.deleteAllData();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                }
        );
    }

    private static String getRandomString(final int sizeOfRandomString) {
        final Random random = new Random();
        final StringBuilder stringBuilder = new StringBuilder(sizeOfRandomString);
        for (int i = 0; i < sizeOfRandomString; ++i)
            stringBuilder.append(ALLOWED_CHARACTERS.charAt(random.nextInt(ALLOWED_CHARACTERS.length())));
        return stringBuilder.toString();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

}
