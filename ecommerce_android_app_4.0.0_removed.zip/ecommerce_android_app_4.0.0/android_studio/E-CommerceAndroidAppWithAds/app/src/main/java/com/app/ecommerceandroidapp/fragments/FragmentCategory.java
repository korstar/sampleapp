package com.app.ecommerceandroidapp.fragments;

import static com.app.ecommerceandroidapp.utilities.Constant.GET_CATEGORY;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.toolbox.JsonArrayRequest;
import com.app.ecommerceandroidapp.Config;
import com.app.ecommerceandroidapp.R;
import com.app.ecommerceandroidapp.activities.ActivityProduct;
import com.app.ecommerceandroidapp.activities.MainActivity;
import com.app.ecommerceandroidapp.activities.MyApplication;
import com.app.ecommerceandroidapp.adapters.AdapterCategory;
import com.app.ecommerceandroidapp.models.Category;
import com.app.ecommerceandroidapp.utilities.MyDividerItemDecoration;
import com.app.ecommerceandroidapp.utilities.Tools;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

public class FragmentCategory extends Fragment {

    RecyclerView recyclerView;
    private List<Category> categoryList;
    private AdapterCategory adapterCategory;
    SwipeRefreshLayout swipeRefreshLayout = null;
    ShimmerFrameLayout lytShimmer;
    Activity activity;
    View rootView;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (Activity) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_category, container, false);
        swipeRefreshLayout = rootView.findViewById(R.id.swipe_refresh_layout);
        lytShimmer = rootView.findViewById(R.id.shimmer_view_container);

        recyclerView = rootView.findViewById(R.id.recycler_view);
        categoryList = new ArrayList<>();

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(activity);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new MyDividerItemDecoration(activity, DividerItemDecoration.VERTICAL, 0));

        adapterCategory = new AdapterCategory(activity, categoryList, category -> {
            Intent intent = new Intent(activity, ActivityProduct.class);
            intent.putExtra("category_id", category.getCategoryId());
            intent.putExtra("category_name", category.getCategoryName());
            startActivity(intent);
            ((MainActivity) activity).showInterstitialAd();
        }, false);
        recyclerView.setAdapter(adapterCategory);

        fetchData();
        onRefresh();

        return rootView;
    }

    private void onRefresh() {
        swipeRefreshLayout.setOnRefreshListener(() -> {
            categoryList.clear();
            swipeProgress(true);
            Tools.postDelayed(this::fetchData, Config.DELAY_REFRESH);
        });
    }

    private void fetchData() {
        @SuppressLint("NotifyDataSetChanged") JsonArrayRequest request = new JsonArrayRequest(GET_CATEGORY, response -> {
            if (response == null) {
                showFailedView(true);
                swipeProgress(false);
                return;
            }

            List<Category> items = new Gson().fromJson(response.toString(), new TypeToken<List<Category>>() {
            }.getType());

            if (items.size() > 0) {
                categoryList.clear();
                categoryList.addAll(items);
                adapterCategory.notifyDataSetChanged();
                showNoItemView(false);
            } else {
                showNoItemView(true);
            }
            showFailedView(false);
            swipeProgress(false);
        }, error -> {
            showFailedView(true);
            swipeProgress(false);
        });

        MyApplication.getInstance().addToRequestQueue(request);
    }

    private void showNoItemView(boolean show) {
        View lytNoItem = rootView.findViewById(R.id.lyt_no_item);
        if (show) {
            lytNoItem.setVisibility(View.VISIBLE);
        } else {
            lytNoItem.setVisibility(View.GONE);
        }
    }

    private void showFailedView(boolean show) {
        View lytFailed = rootView.findViewById(R.id.lyt_failed);
        if (show) {
            lytFailed.setVisibility(View.VISIBLE);
        } else {
            lytFailed.setVisibility(View.GONE);
        }
    }

    private void swipeProgress(boolean show) {
        if (show) {
            swipeRefreshLayout.setRefreshing(true);
            lytShimmer.setVisibility(View.VISIBLE);
            lytShimmer.startShimmer();
            recyclerView.setVisibility(View.GONE);
        } else {
            swipeRefreshLayout.setRefreshing(false);
            lytShimmer.setVisibility(View.GONE);
            lytShimmer.stopShimmer();
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

}